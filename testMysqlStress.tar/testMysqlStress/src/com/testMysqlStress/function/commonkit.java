package com.testMysqlStress.function;

import java.util.Date;

public class commonkit {

	//生成随机数
	public int random() {
		int max=100,min=1;
		int result = 0;
		result = (int) (Math.random()*(max-min)+min);
		return result;
	}
	
	//获取当前时间
	public Long Time(){
		Date dt= new Date();
		long start = dt.getTime();
		return start;
	}
}
