package com.testMysqlStress.function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.testMysqlStress.resource.createTbField;

public class controlMySql extends createTbField {
	
	private String host;
	private String user;
	private String pass;
	private String port;
	private String database;
	
	public controlMySql(String h,String u,String ps,String pt,String db) {
		host = h;
		user = u;
		pass = ps;
		port = pt;
		database = db;
	}
	
	//定义数据库操作
	PreparedStatement ps = null;
	Connection ct = null;
	ResultSet rs = null;
	commonkit ck = new commonkit();
	
	
	/**
	 * 建表操作
	 * @param tbIdx
	 * @param tbKind
	 */
	public void createtb(int tbIdx,String tbKind) {
		
		String createtb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+"/"+database+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("创建普通表");
				createtb = "create table  "+TBNAME+""+tbIdx+" ("+COMMONTBFILED+";";
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
			ps = ct.prepareStatement(createtb);
			ps.executeUpdate();
			
			
		}catch (Exception eCreatetb) {
			eCreatetb.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}
	
	/**
	 * 插入记录
	 * @param tbIdx
	 * @param tbKind
	 */
	public void inserttb(int tbIdx,String tbKind) {
		String istTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+"/"+database+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("写入普通表");
				istTb = "insert into "+TBNAME+""+tbIdx+"  values "+ ISTCOMMONTBVALUE;
//				System.out.println(" -- insert into tb_com_"+tbIdx+"  values "+ ISTCOMMONTBVALUE);
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
			ps = ct.prepareStatement(istTb);
			ps.executeUpdate();
		}catch (Exception einserttb) {
			einserttb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}
	
	/**
	 * 删除记录
	 * @param tbIdx
	 * @param tbKind
	 */
	public void deletetb(int tbIdx,String tbKind) {
		String detTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+"/"+database+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("删除普通表记录");
				detTb = "delete from "+TBNAME+""+tbIdx+" where id = "+ck.random()+"";
//				System.out.println(" -- insert into tb_com_"+tbIdx+"  values "+ ISTCOMMONTBVALUE);
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
			ps = ct.prepareStatement(detTb);
			ps.executeUpdate();
		}catch (Exception edeletetb) {
			edeletetb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}

	//更新记录
	public void updatetb(int tbIdx,String tbKind) {
		String updateTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+"/"+database+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("更新普通表记录");
//				updateTb = "delete from "+TBNAME+""+tbIdx+" where id = "+ck.random()+"";
				updateTb = "update "+TBNAME+""+tbIdx+" set tinyid = 5 where id "+ck.random()+"";
				System.out.println(" --  update "+TBNAME+""+tbIdx+" set tinyid = 5 where id = "+ck.random()+"");
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
			ps = ct.prepareStatement(updateTb);
			ps.executeUpdate();
		}catch (Exception eupdatetb) {
			eupdatetb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}

}
