package com.testMysqlStress.function;

import com.testMysqlStress.threads.runMysqlDelete;
import com.testMysqlStress.threads.runMysqlInsert;

public class main {

	public static void main(String[] args) {
		
//		String host = args[0];
//		String user = args[1];
//		String pass = args[2];
//		String port = args[3];
//		String db = args[4];
//		String exeType = args[5]; //记次运行或计时运行
		
		System.out.println("Mysql Stress Testing tool .");
		controlMySql ctMysql = new controlMySql("172.16.110.12","root","Abc@1234","16310","mytest");
//		controlMySql ctMysql = new controlMySql(args[0],args[1],args[2],args[3],args[4]);
		commonkit ck = new commonkit();
		ctMysql.createtb(0, "common");
//		System.out.println("host:"+args[0]+" ，Test type : "+args[5]+" ,Lasting test ： "+args[6]+ " Threads ： "+args[7]);
	/*	
		if(exeType.equals("count")) {
			int loop = Integer.valueOf(args[6]);//记次
			int threadnum = Integer.valueOf(args[7]);//并发线程数
			
			for(int i=0;i<loop;i++) {
				for(int j = 0;j<threadnum;j++) {
					Thread tj = new Thread(new runMysqlInsert(0,"common"));
					tj.start();
					try {
						tj.sleep(50);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		if(exeType.equals("time")) {
			int time = Integer.valueOf(args[6]);//计时
			int threadnum = Integer.valueOf(args[7]);//并发线程数
			Long max = ck.Time()+time * 1000;
			while(ck.Time() < max) {
				for(int j = 0;j<threadnum;j++) {
					Thread tj = new Thread(new runMysqlInsert(0,"common"));
					tj.start();
					try {
						tj.sleep(50);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	*/	
		
//		for(int loop=0;loop<1000;loop++) {
//			for(int threadnum = 0;threadnum<8;threadnum++) {
//				Thread tthreadnum = new Thread(new runMysqlDelete(0,"common"));
//				tthreadnum.start();
//				try {
//					tthreadnum.sleep(50);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//		}
		
	}

}
