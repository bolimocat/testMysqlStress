package com.testMysqlStress.threads;

import com.testMysqlStress.function.controlMySql;

public class runMysqlDelete  implements Runnable{

	controlMySql ctMysql = new controlMySql("192.168.130.15","u1","123456","3306","mytest");
	
	private int idx;
	private String tbKind;
	public runMysqlDelete(int i,String k) {
		idx = i;
		tbKind = k;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		ctMysql.deletetb(idx, tbKind);
	}

}
