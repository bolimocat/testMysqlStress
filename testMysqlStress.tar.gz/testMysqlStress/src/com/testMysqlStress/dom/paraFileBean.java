package com.testMysqlStress.dom;

public class paraFileBean {

	private String fileLine;

	public String getFileLine() {
		return fileLine;
	}

	public void setFileLine(String fileLine) {
		this.fileLine = fileLine;
	}
}
