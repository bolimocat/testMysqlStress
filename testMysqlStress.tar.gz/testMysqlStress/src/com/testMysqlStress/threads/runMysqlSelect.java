package com.testMysqlStress.threads;

import com.testMysqlStress.function.controlMySql;

public class runMysqlSelect implements Runnable {

	private String host;
	private String user;
	private String pass;
	private String port;
	private String database;
	private String tbKind;
	private String paraFiled;
	private String paraCondition;
	private int tbnum;
	
	
	public runMysqlSelect(String h,String u,String p,String pt,String db,String k,String f,String c,int n) {
		host = h;
		user = u;
		pass = p;
		port = pt;
		database = db;
		tbKind = k;
		paraFiled = f;
		paraCondition = c;
		tbnum = n;
	}
	controlMySql ctMysql = new controlMySql(host,user,pass,port,database);
	@Override
	public void run() {
		// TODO Auto-generated method stub
		ctMysql.selecttb(host, user, pass, port, database, tbKind,paraFiled,paraCondition,tbnum);
	}

}
