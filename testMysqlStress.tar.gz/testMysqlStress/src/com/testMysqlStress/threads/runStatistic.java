package com.testMysqlStress.threads;

public class runStatistic  implements Runnable{

	private int threads;
	private int tps;
	private int qps;
	private Long lat95;
	private String recordTime;
	
	
//	public runStatistic(int ths,int t,int q,Long lat,Long time) {
//		threads = ths;
//		tps = t;
//		qps = q;
//		lat95 = lat;
//		recordTime = String.valueOf(time);
//	}
	public runStatistic(int ths) {
		threads = ths;
//		tps = t;
//		qps = q;
//		lat95 = lat;
//		recordTime = String.valueOf(time);
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("[ "+recordTime+" ] thds: "+threads+"");
//		[ 230s ] thds: 32 tps: 820.00 qps: 820.00 (r/w/o: 0.00/820.00/0.00) lat (ms,95%): 55.82 err/s: 0.00 reconn/s: 0.00
	}

}
