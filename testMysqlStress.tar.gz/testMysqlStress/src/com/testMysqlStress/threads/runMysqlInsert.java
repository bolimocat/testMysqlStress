package com.testMysqlStress.threads;

import com.testMysqlStress.function.controlMySql;
//import com.testMysqlStress.statistic.statisticInfo;

public class runMysqlInsert implements Runnable{

	
	
	private String host;
	private String user;
	private String pass;
	private String port;
	private String database;
	private String tbKind;
	private int tbnum;
	
	
	
//	statisticInfo ssi = new statisticInfo();
	
	public runMysqlInsert(String h,String u,String p,String pt,String db,String k,int n) {
		host = h;
		user = u;
		pass = p;
		port = pt;
		database = db;
		tbKind = k;
		tbnum = n;
		
	}
	controlMySql ctMysql = new controlMySql(host,user,pass,port,database);
	@Override
	public void run() {
		// TODO Auto-generated method stub
		ctMysql.inserttb(host,user,pass,port,database,tbKind,tbnum);
		
		
	}

}
