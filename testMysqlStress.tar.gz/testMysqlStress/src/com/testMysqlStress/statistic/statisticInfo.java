//统计信息
package com.testMysqlStress.statistic;

public class statisticInfo {
	
	public int tnums;
	public int qnums;
	public Long allTime;

}
