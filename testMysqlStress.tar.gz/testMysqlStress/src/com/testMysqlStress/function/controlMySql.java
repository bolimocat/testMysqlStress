package com.testMysqlStress.function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.testMysqlStress.resource.createTbField;
import com.testMysqlStress.statistic.statisticInfo;

public class controlMySql extends createTbField {
	
	private String host;
	private String user;
	private String pass;
	private String port;
	private String database;
//	t为所有事务，包括写入和查询
	public static int tnums = 1;
	public static int tfnums = 1;
	public  static Long tfasted = 10000l;
	public  static Long tslowed = 0l;
	public  static Long tall = 0l;
	public  static Long tconsume = 0l;
// q为所有查询事务，不包括写入
	public static int qnums = 1;
	public static int qfnums = 1;
	public  static Long qfasted = 10000l;
	public  static Long qslowed = 0l;
	public  static Long qall = 0l;
	public  static Long qconsume = 0l;
	
//	statisticInfo ssi = new statisticInfo();
	
	public controlMySql(String h,String u,String ps,String pt,String db) {
		host = h;
		user = u;
		pass = ps;
		port = pt;
		database = db;
	}
	
	//定义数据库操作
	PreparedStatement ps = null;
	Connection ct = null;
	ResultSet rs = null;
	commonkit ck = new commonkit();
	
	
	/**
	 * 建表操作
	 * @param tbIdx
	 * @param tbKind
	 */
	public void createtb(String tbKind,int tbNum) {
		
		String createtb = "";
		System.out.println("执行建表... ...");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+":"+port+"/"+database+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("创建普通表");
				for(int i=0;i<tbNum;i++) {
					System.out.println("建表： "+CMTBNAME+"_"+i);
					createtb = "create table  "+CMTBNAME+"_"+i+" ("+COMMONTBFILED+";";
					ps = ct.prepareStatement(createtb);
					ps.executeUpdate();
				}
				
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
				for(int i=0;i<tbNum;i++) {
					System.out.println("建表： "+HSTBNAME+"_"+i);
					createtb = "create table "+HSTBNAME+"_"+i+" ("+HSTBFILED+";";
					ps = ct.prepareStatement(createtb);
					ps.executeUpdate();
				}
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
				for(int i=0;i<tbNum;i++) {
					System.out.println("建表： "+RGTBNAME+"_"+i);
					createtb = "create table "+RGTBNAME+"_"+i+" ("+RGTBFILED+";";
					ps = ct.prepareStatement(createtb);
					ps.executeUpdate();
				}
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
				for(int i=0;i<tbNum;i++) {
					System.out.println("建表： "+LSTBNAME+"_"+i);
					createtb = "create table "+LSTBNAME+"_"+i+" "+LTTBFILED+";";
					ps = ct.prepareStatement(createtb);
					ps.executeUpdate();
				}
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
				for(int i=0;i<tbNum;i++) {
					System.out.println("建表： "+LSTBNAME+"_"+i);
					createtb = "create table "+LSTBNAME+"_"+i+" ("+MDTBFILED+";";
					ps = ct.prepareStatement(createtb);
					ps.executeUpdate();
				}
				
			}
			
			
			
		}catch (Exception eCreatetb) {
			eCreatetb.printStackTrace();
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
		System.out.println("建表完成... ...");
	}
	
	/**
	 * 插入记录
	 * @param tbIdx
	 * @param tbKind
	 */
	public void inserttb(String host,String user,String pass,String port,String db,String tbKind,int tbnum) {
		String istTb = "";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+":"+port+"/"+db+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
//				System.out.println("写入普通表");
				for(int i=0;i<tbnum;i++) {
					istTb = "insert into "+CMTBNAME+"_"+i+"  values "+ ISTTBVALUE;
					ps = ct.prepareStatement(istTb);
					Long start = ck.Time();
					if(ps.executeUpdate()>0) {
						ps.executeUpdate();
						tnums = tnums + 1;
					}
					else {
						tfnums = tfnums + 1;
						System.out.println("INSERT ERROR : "+istTb);
					}
					Long end = ck.Time();
					tconsume = ck.timer(start, end);
					
					tall = tall + tconsume;
					if(tconsume < tfasted ) {
						tfasted = tconsume;
					}
					if(tconsume >= tfasted ) {
						tfasted = tfasted;
					}
					
					
					if(tconsume > tslowed) {
						tslowed = tconsume;
					}
					if(tconsume <= tslowed) {
						tslowed = tslowed;
					}
				}
				
			}
			if(tbKind.equals("hash")) {
//				System.out.println("写入hash分片表");
				for(int i=0;i<tbnum;i++) {
					istTb = "insert into "+HSTBNAME+"_"+i+"  values "+ ISTTBVALUE;
					ps = ct.prepareStatement(istTb);
					Long start = ck.Time();
					if(ps.executeUpdate()>0) {
						ps.executeUpdate();
						tnums = tnums + 1;
					}
					else {
						tfnums = tfnums + 1;
					}
					Long end = ck.Time();
					tconsume = ck.timer(start, end);
					tnums = tnums + 1;
					tall = tall + tconsume;
					if(tconsume < tfasted ) {
						tfasted = tconsume;
					}
					if(tconsume >= tfasted ) {
						tfasted = tfasted;
					}
					
					
					if(tconsume > tslowed) {
						tslowed = tconsume;
					}
					if(tconsume <= tslowed) {
						tslowed = tslowed;
					}
				}
				
				
				
			}
			if(tbKind.equals("range")) {
//				System.out.println("写入range分片表");
				for(int i=0;i<tbnum;i++) {
					istTb = "insert into "+RGTBNAME+"_"+i+"  values "+ ISTTBVALUE;
					ps = ct.prepareStatement(istTb);
					Long start = ck.Time();
					if(ps.executeUpdate()>0) {
						ps.executeUpdate();
						tnums = tnums + 1;
					}
					else {
						tfnums = tfnums + 1;
					}
					Long end = ck.Time();
					tconsume = ck.timer(start, end);
					tnums = tnums + 1;
					tall = tall + tconsume;
					if(tconsume < tfasted ) {
						tfasted = tconsume;
					}
					if(tconsume >= tfasted ) {
						tfasted = tfasted;
					}
					
					
					if(tconsume > tslowed) {
						tslowed = tconsume;
					}
					if(tconsume <= tslowed) {
						tslowed = tslowed;
					}
				}
				
			}
			if(tbKind.equals("list")) {
//				System.out.println("写入list分片表");
				for(int i=0;i<tbnum;i++) {
					istTb = "insert into "+LSTBNAME+"_"+i+"  values "+ ISTTBVALUE;
					ps = ct.prepareStatement(istTb);
					Long start = ck.Time();
					if(ps.executeUpdate()>0) {
						ps.executeUpdate();
						tnums = tnums + 1;
					}
					else {
						tfnums = tfnums + 1;
					}
					Long end = ck.Time();
					tconsume = ck.timer(start, end);
					tnums = tnums + 1;
					tall = tall + tconsume;
					if(tconsume < tfasted ) {
						tfasted = tconsume;
					}
					if(tconsume >= tfasted ) {
						tfasted = tfasted;
					}
					
					
					if(tconsume > tslowed) {
						tslowed = tconsume;
					}
					if(tconsume <= tslowed) {
						tslowed = tslowed;
					}
				}
				
			}
			if(tbKind.equals("mod")) {
//				System.out.println("写入mod分片表");
				for(int i=0;i<tbnum;i++) {
					istTb = "insert into "+MDTBNAME+"_"+i+"  values "+ ISTTBVALUE;
					ps = ct.prepareStatement(istTb);
					Long start = ck.Time();
					if(ps.executeUpdate()>0) {
						ps.executeUpdate();
						tnums = tnums + 1;
					}
					else {
						tfnums = tfnums + 1;
					}
					Long end = ck.Time();
					tconsume = ck.timer(start, end);
					tnums = tnums + 1;
					tall = tall + tconsume;
					if(tconsume < tfasted ) {
						tfasted = tconsume;
					}
					if(tconsume >= tfasted ) {
						tfasted = tfasted;
					}
					
					
					if(tconsume > tslowed) {
						tslowed = tconsume;
					}
					if(tconsume <= tslowed) {
						tslowed = tslowed;
					}
				}
				
			}
			
		
			
			
		}catch (Exception einserttb) {
			einserttb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	
	}
	
	/**
	 * 删除记录
	 * @param tbIdx
	 * @param tbKind
	 */
	public void deletetb(String host,String user,String pass,String port,String db,String tbKind) {
		String detTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+":"+port+"/"+db+"";
			ct = DriverManager.getConnection(url, user, pass);
			
			if(tbKind.equals("common")) {
				System.out.println("删除普通表记录");
				detTb = "delete from "+CMTBNAME+" where id = "+ck.random()+"";
			}
			if(tbKind.equals("hash")) {
				System.out.println("删除hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("删除range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("删除list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("删除mod分片表");
			}
			ps = ct.prepareStatement(detTb);
			ps.executeUpdate();
		}catch (Exception edeletetb) {
			edeletetb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}

	/**
	 * 更新记录
	 * @param host
	 * @param user
	 * @param pass
	 * @param port
	 * @param db
	 * @param tbKind
	 */
	public void updatetb(String host,String user,String pass,String port,String db,String tbKind) {
		String updateTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			if(tbKind.equals("common")) {
				System.out.println("更新普通表记录");
				updateTb = "update "+CMTBNAME+" set tinyid = 5 where id "+ck.random()+"";
				System.out.println(" --  update "+CMTBNAME+" set tinyid = 5 where id = "+ck.random()+"");
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
			ps = ct.prepareStatement(updateTb);
			ps.executeUpdate();
		}catch (Exception eupdatetb) {
			eupdatetb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}

	/**
	 * 查询操作
	 * @param host
	 * @param user
	 * @param pass
	 * @param port
	 * @param db
	 * @param tbKind
	 */
	public void selecttb(String host,String user,String pass,String port,String db,String tbKind,String paraFiled,String paraCondition,int tbnum) {
		String selectTb = "";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://"+host+":"+port+"/"+db+"";
			ct = DriverManager.getConnection(url, user, pass);

			if(tbKind.equals("common")) {
//				System.out.println("查询普通表记录");
				if((paraFiled.equals(""))||(paraCondition.equals(""))) {
					selectTb = "select "+SELECTFILED+" from "+CMTBNAME+"_"+tbnum+" where "+SELECTCONDITION+" ;";
				}
				else {
					selectTb = "select "+paraFiled+" from "+CMTBNAME+"_"+tbnum+" where "+paraCondition+" ;";
				}
//				System.out.println(" == select == "+selectTb);
			}
			if(tbKind.equals("hash")) {
				System.out.println("创建hash分片表");
			}
			if(tbKind.equals("range")) {
				System.out.println("创建range分片表");
			}
			if(tbKind.equals("list")) {
				System.out.println("创建list分片表");
			}
			if(tbKind.equals("mod")) {
				System.out.println("创建mod分片表");
			}
		
			ps = ct.prepareStatement(selectTb);
//			ps = ct.prepareStatement("select * from tb_common where id = 5;");
			Long start = ck.Time();
			rs = ps.executeQuery();
			if(rs.next()) {
				qnums = qnums + 1;
			}
			else {
				qfnums = qfnums + 1;
				System.out.println("QUERY ERROR : "+selectTb);
			}
			Long end = ck.Time();
			qconsume = ck.timer(start, end);
			
			qall = qall + qconsume;
			if(qconsume < qfasted ) {
				qfasted = qconsume;
			}
			if(qconsume >= qfasted ) {
				qfasted = qfasted;
			}
			
			
			if(qconsume > qslowed) {
				qslowed = qconsume;
			}
			if(qconsume <= qslowed) {
				qslowed = qslowed;
			}
			
			
		}catch (Exception eupdatetb) {
			eupdatetb.printStackTrace();
		
		}
		finally{
			try {
				if(rs!=null) rs.close();
				if(ps!=null) ps.close();
				if(ct!=null) ct.close();
			} catch (Exception eCloseDb) {
				eCloseDb.printStackTrace();
			}
		}
	}


}
